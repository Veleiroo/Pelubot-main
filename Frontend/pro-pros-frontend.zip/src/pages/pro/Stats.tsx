import ProsStatsView from '@/features/pro/stats';

const ProsStats = () => <ProsStatsView />;

export default ProsStats;
