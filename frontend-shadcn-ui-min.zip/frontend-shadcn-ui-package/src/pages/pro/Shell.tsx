export { ProsShell, ProsShell as default } from '@/features/pro/layout/ProsShell';
