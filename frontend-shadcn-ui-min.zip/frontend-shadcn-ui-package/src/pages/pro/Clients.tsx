export { ProsClientsView, ProsClientsView as default } from '@/features/pro/clients';
