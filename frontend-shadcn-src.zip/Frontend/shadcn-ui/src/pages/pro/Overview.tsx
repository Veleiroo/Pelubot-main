export { ProsOverviewView, ProsOverviewView as default } from '@/features/pro/overview';
