export { MOCK_APPOINTMENTS } from '@/features/pro/agenda/data/mocks';
