export {
  STATUS_STYLES,
  MIN_APPOINTMENTS_CARD_HEIGHT,
  WEEKDAY_LABELS,
} from '@/features/pro/shared/constants';
