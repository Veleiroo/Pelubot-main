export type {
  AppointmentStatus,
  Appointment,
  AgendaSummary,
} from '@/features/pro/shared/types';
