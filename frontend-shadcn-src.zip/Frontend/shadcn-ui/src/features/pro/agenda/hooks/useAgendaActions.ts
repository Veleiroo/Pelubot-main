import { useMutation, useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';

import { api, type ProReservation, type ProReservationsResponse } from '@/lib/api';

const combineDateAndTime = (date: Date, time: string) => {
  const [hours, minutes] = time.split(':').map((value) => Number.parseInt(value, 10));
  const safeHours = Number.isFinite(hours) ? hours : 0;
  const safeMinutes = Number.isFinite(minutes) ? minutes : 0;
  const next = new Date(date.getFullYear(), date.getMonth(), date.getDate(), safeHours, safeMinutes, 0, 0);
  return next;
};

const minutesToMs = (minutes?: number) => (Number.isFinite(minutes) && minutes ? minutes * 60_000 : 45 * 60_000);

const sortReservations = (reservations: ProReservation[]) =>
  [...reservations].sort(
    (a, b) => new Date(a.start).getTime() - new Date(b.start).getTime()
  );

const upsertReservation = (reservations: ProReservation[], reservation: ProReservation) =>
  sortReservations(reservations.filter((item) => item.id !== reservation.id).concat(reservation));

const removeReservation = (reservations: ProReservation[], reservationId: string) =>
  reservations.filter((reservation) => reservation.id !== reservationId);

type CreateAppointmentPayload = {
  date: Date;
  time: string;
  serviceId: string;
  serviceName: string;
  durationMinutes?: number;
  clientName: string;
  clientPhone?: string;
  clientEmail?: string;
  notes?: string;
};

type ReschedulePayload = {
  reservationId: string;
  date: Date;
  newTime: string;
  durationMinutes?: number;
};

type CancelPayload = { reservationId: string };

type AgendaActionsOptions = {
  professionalId?: string | null;
};

export const useAgendaActions = ({ professionalId }: AgendaActionsOptions) => {
  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: async (payload: CreateAppointmentPayload) => {
      if (!professionalId) throw new Error('No hay profesional activo para crear la reserva.');

      const startDate = combineDateAndTime(payload.date, payload.time);
      const startIso = startDate.toISOString();
      const durationMs = minutesToMs(payload.durationMinutes);
      const endIso = new Date(startDate.getTime() + durationMs).toISOString();

      const response = await api.createReservation({
        service_id: payload.serviceId,
        professional_id: professionalId,
        start: startIso,
        customer_name: payload.clientName,
        ...(payload.clientPhone ? { customer_phone: payload.clientPhone } : {}),
        ...(payload.clientEmail ? { customer_email: payload.clientEmail } : {}),
        ...(payload.notes ? { notes: payload.notes } : {}),
      });

      const reservation: ProReservation = {
        id: response.reservation_id,
        service_id: payload.serviceId,
        service_name: payload.serviceName,
        professional_id: professionalId,
        start: startIso,
        end: endIso,
        customer_name: payload.clientName,
        customer_phone: payload.clientPhone,
        customer_email: payload.clientEmail,
        notes: payload.notes,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      return { response, reservation };
    },
    onSuccess: ({ reservation }) => {
      queryClient.setQueriesData<ProReservationsResponse>({ queryKey: ['pros', 'reservations'] }, (previous) => {
        if (!previous) return previous;
        return { reservations: upsertReservation(previous.reservations, reservation) };
      });
      void queryClient.invalidateQueries({ queryKey: ['pros', 'reservations'] });
    },
  });

  const rescheduleMutation = useMutation({
    mutationFn: async (payload: ReschedulePayload) => {
      const startDate = combineDateAndTime(payload.date, payload.newTime);
      const startIso = startDate.toISOString();
      const durationMs = minutesToMs(payload.durationMinutes);
      const endIso = new Date(startDate.getTime() + durationMs).toISOString();

      const response = await api.prosRescheduleReservation(payload.reservationId, {
        new_date: format(payload.date, 'yyyy-MM-dd'),
        new_time: payload.newTime,
      });

      return { response, reservationId: payload.reservationId, startIso, endIso };
    },
    onSuccess: ({ reservationId, startIso, endIso }) => {
      queryClient.setQueriesData<ProReservationsResponse>({ queryKey: ['pros', 'reservations'] }, (previous) => {
        if (!previous) return previous;
        const next = previous.reservations.map((reservation) =>
          reservation.id === reservationId
            ? {
                ...reservation,
                start: startIso,
                end: endIso,
                updated_at: new Date().toISOString(),
              }
            : reservation
        );
        return { reservations: sortReservations(next) };
      });
      void queryClient.invalidateQueries({ queryKey: ['pros', 'reservations'] });
    },
  });

  const cancelMutation = useMutation({
    mutationFn: async (payload: CancelPayload) => {
      const response = await api.prosCancelReservation(payload.reservationId);
      return { response, reservationId: payload.reservationId };
    },
    onSuccess: ({ reservationId }) => {
      queryClient.setQueriesData<ProReservationsResponse>({ queryKey: ['pros', 'reservations'] }, (previous) => {
        if (!previous) return previous;
        return { reservations: removeReservation(previous.reservations, reservationId) };
      });
      void queryClient.invalidateQueries({ queryKey: ['pros', 'reservations'] });
    },
  });

  return {
    createAppointment: createMutation.mutateAsync,
    rescheduleAppointment: rescheduleMutation.mutateAsync,
    cancelAppointment: cancelMutation.mutateAsync,
    isCreating: createMutation.isPending,
    isRescheduling: rescheduleMutation.isPending,
    isCancelling: cancelMutation.isPending,
  };
};
