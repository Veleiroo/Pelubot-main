export { AppointmentsCard as AgendaAppointmentsCard } from '@/features/pro/agenda/components/appointments-card';
export type { AgendaAppointmentsCardProps } from '@/features/pro/agenda/types';
