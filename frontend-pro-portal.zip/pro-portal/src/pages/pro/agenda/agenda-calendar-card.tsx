export { CalendarCard as AgendaCalendarCard } from '@/features/pro/agenda/components/calendar-card';
export type { AgendaCalendarCardProps } from '@/features/pro/agenda/types';
