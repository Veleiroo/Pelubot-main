import ProsAgendaView from '@/features/pro/agenda';

const ProsAgenda = () => <ProsAgendaView />;

export default ProsAgenda;
