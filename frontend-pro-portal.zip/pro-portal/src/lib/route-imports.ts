export const loadProsLogin = () => import('@/pages/pro/Login');
export const loadProsOverview = () => import('@/pages/pro/Overview');
export const loadProsShell = () => import('@/pages/pro/Shell');
export const loadProsAgenda = () => import('@/pages/pro/Agenda');
export const loadProsClients = () => import('@/pages/pro/Clients');
export const loadProsStats = () => import('@/pages/pro/Stats');
